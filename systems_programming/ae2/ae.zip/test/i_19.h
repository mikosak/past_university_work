#ifndef _I_19_H_
#define _I_19_H_

#include <netinet/ip.h> /* defines in_addr */

#endif /* _I_19_H_ */
