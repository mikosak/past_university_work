#ifndef _I_24_H_
#define _I_24_H_

#include <stdint.h>

#endif /* _I_24_H_ */
